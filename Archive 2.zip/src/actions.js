export const LOGIN = "LOGIN";
export const SEND_INFO = "SEND_INFO";
export const SEND_INFO2 = "SEND_INFO2";
export const SENDED_COMMENT_ID = "SENDED_COMMENT_ID";
export const DELETE_ARRAY = "DELETE_ARRAY";
