import { LOGIN, LOGOUT } from "../actions";
const initialState = {
    isLoggedIn: false,
};
const reducer = (state = initialState, action) => {
    if (action.type === LOGIN) {
        return { ...state, isLoggedIn: action.payload };
    }
    if (action.type === LOGOUT) {
        return { ...state, isLoggedIn: false };
    }
    return state;
};

export default reducer;
