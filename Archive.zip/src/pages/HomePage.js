import React from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
const HomePage = () => {
    return (
        <Wrapper>
            <h2>Home</h2>
            <ul>
                <li>
                    <Link to="/login">Login</Link>
                </li>
                <li>
                    <Link to="/register">Registration</Link>
                </li>
                <li>
                    <Link to="/articles">Article</Link>
                </li>
            </ul>
        </Wrapper>
    );
};

const Wrapper = styled.div`
    padding: 1.5rem;
    li {
        text-decoration: underline;
    }
`;
export default HomePage;
