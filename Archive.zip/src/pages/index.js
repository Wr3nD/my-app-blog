import Login from "./LoginPage";
import Home from "./HomePage";
// import SingleProduct from "./SingleProductPage";
// import Admin from "./AdminPage";
import Register from "./RegisterPage";
import Error from "./ErrorPage";

export { Login, Home, Error, Register };
