import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {
    Login,
    Products,
    SingleProduct,
    Admin,
    Register,
    Home,
    Error,
} from "./pages";
import { Footer, Navbar } from "./components";
function App() {
    return (
        <>
            <Router>
                <Navbar />
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    {/* <Route path="/admin" element={<Admin />} />
                    <Route path="/products" element={<Products />} />
                    <Route path="/products/:id" element={<SingleProduct />} /> */}
                    <Route path="*" element={<Error />} />
                </Routes>
                <Footer />
            </Router>
        </>
    );
}

export default App;
